package com.vinh.doctor_x.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.vinh.doctor_x.R;

/**
 * Created by nntd290897 on 3/20/18.
 */

public class Frg_tabnext_indoctor extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.frg_tabnext_indoctor, container, false);
    }
}